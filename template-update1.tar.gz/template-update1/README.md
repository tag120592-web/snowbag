# Шаблон проекта example.ru

## Создать папку с названием проекта
```
/opt/prj/example.ru
```

## Скопировать в нее содержимое данного репозитория и запустить скрипт сборки
```
bash ./build.sh
```

## После сборки запустить скрипт запуска
```
bash ./up.sh
```

## Шаблон для создания VM через yc
```
start cmd

yc compute instance create ^
    --cloud-id b1g94vb73dlv93sq1kso ^
    --folder-name example ^
    --name example-stage-20201229 ^
    --hostname example-stage-20201229 ^
    --create-boot-disk name=example-stage-20201229,type=network-ssd,size=65G,image-folder-id=standard-images,image-family=ubuntu-1804-lts ^
    --network-interface subnet-name=default-ru-central1-b,nat-ip-version=ipv4,nat-address=84.201.140.1,security-group-ids=enpjj3ttm4hmplat8vh4 ^
    --zone ru-central1-b ^
    --memory 4 ^
    --cores 2 ^
    --metadata serial-port-enable=1 ^
    --metadata-from-file user-data=infra/vm.yml

```

## Общие концепции
Работа с секретами описана в файле [SECRETS.md](SECRETS.md). 
- Секреты нужно настроить до начала работы и сразу после установки нового сервера
- Без этого сборка будет завершаться ошибкой публикации в docker registry

Инструкции по настройке конкретных сред пишутся в индивидуальных файлах:
- Продуктивная среда в файле [PROD.md](PROD.md)
- Стэйджинг в файле [STAGE.md](STAGE.md)
- Тестовая среда в файле [TEST.md](TEST.md)

Учет задач по разработке ведется в корпоративном [Яндекс.Трекер](http://tracker.tn.ru/) в очереди ???

Список задач по улучшению данного репозитория ведется в файле [TODO.md](TODO.md)

### Репозитории

Используемые в проекте Git репозитории описываются в файле ```.build.repository```

### Переменные окружения

Общие параметры сборки описываются в файлах ```.build.* ```

Текущая среда описывается переменной DEPLOYMENT в файле [.build.deployment](.build.deployment) и в дальнейшем ссылки на нее идут через значение переменной ${DEPLOYMENT}

Типичные виды сред:
- prod - продуктив
- stage - стэйджинг для тестирования перед обновлением продуктива
- test - тестовая среда для проверки сборок

Но можно использовать необходимое количество сред, включая среды для разработчиков и интеграционные

Общие для всех сред переменные окружения располагаются в файлах ```.env.* ```

Индивидуальные переменные для сред описываются в файлах ```.env.*.${DEPLOYMENT} и .build.*.${DEPLOYMENT}```

Для каждой среды делается индивидуальный файл docker compose имеющие имя: docker-compose.${DEPLOYMENT}.yml

### Патчи

Патчи общие для всех сред располагаются в папке [patches](patches/) и накладываются копированием файлов из этой папки в папки с репозиториями

Индивидуальные для конкретной среды патчи располагаются в папке ```patches.*.${DEPLOYMENT}```

Обычно туда кладутся файлы с сертификатами


### Генерация случайных паролей 
```bash
tr -dc A-Za-z0-9_ < /dev/urandom | head -c 10 | xargs
```

### Автоматизация развертывания
CI GitLab

### Установка CLI (yc) для управления Яндекс.Облако
https://cloud.yandex.ru/docs/cli/operations/install-cli

```bash
curl https://storage.yandexcloud.net/yandexcloud-yc/install.sh | bash
```

Помечаем все *.sh файлы как исполняемые
```
git add --chmod=+x *.sh
```

yaml файлы проверять используя:
https://github.com/adrienverge/yamllint

Файл настроек в infra/yamllint.yaml
